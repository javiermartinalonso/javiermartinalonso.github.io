## Apache Maven Tutorial

Source code for mkyong.com Apache Maven tutorial

https://www.mkyong.com/tutorials/maven-tutorials/